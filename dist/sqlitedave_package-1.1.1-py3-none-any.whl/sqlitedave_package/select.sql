/*
  -- Dave Skura, 2022
*/

SELECT *
FROM A;